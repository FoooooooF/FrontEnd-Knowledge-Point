export {a,b} from './c'; // 连写  导入直接导出 
// console.log(a) 不能获取到这个变量
let c = 1;
export {
    c
}

