// module.exports / exports.xxx = 123 
// module.exports.xxx = 123;
// global.xxx 特点污染全局 
// global.a = 123;
// exports.a= 'hello';
module.exports = 'hello';
console.log('file')

// 错误写法 exports = 123;



