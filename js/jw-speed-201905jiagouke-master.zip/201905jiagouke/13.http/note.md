## 缓存
- Expires
- Cache-Control
- if-none-match etag
- if-modified-since if-none-match

- accept-encoding  content-encoding
- userAgent (区分 是pc 还是 mobile)  Location 301 / 302



- 周日
- 代理 实现服务端代理 http-proxy
- 虚拟主机 host
- 多语言 
- 跨域
- cookie 
- 文件上传 header

- koa 原理 (几百行)
- koa中间件 koa-router koa-static koa-views koa-bodyparser koa-session

- cookie + session + jwt
- 写一版本 简版的express 掌握express内置原理
- 周末 一天的时间 express 整个写一遍 

- webapck / react